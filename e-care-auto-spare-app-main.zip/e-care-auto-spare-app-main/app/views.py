
from django.http import HttpResponse
from django.shortcuts import render,redirect
from .models import autocare,booking_wash, car_delivery, car_sales, repair,spare_bookings,timeslots,Aviableslots,slotbooked,contactus
from .allforms import Autocareform,bookingform, carform,spareform
from django.contrib import messages

# Create your views here.
def index(req):
    # return HttpResponse("welcome to our website")
    return render(req,"index.html")


def login(req):
    if req.method == 'POST':
        # return HttpResponse(req.POST)
        print(req.POST)
        print("hello......")
        un =req.POST['email']
        pas= req.POST['password']        
        if autocare.objects.filter(email=un,password=pas):
                req.session['email']=un
                if req.session.has_key('email'):
                    return render(req,'profile.html')
        else:
                return render(req,'login.html')
    else:
        return render(req,'login.html')

def logout(req):
    if req.session.has_key('email'):
        del req.session['email']
        req.session.modified=True
        return redirect(login)    
            
def Profile(req):
    return render (req,'profile.html') 


def aboutus(req):
    return render(req,'aboutus.html')   
    
         
def contact_us(req):
    if req.method == 'POST':
        print(req.POST)
        email = req.POST['email']
        description = req.POST['description']
        contactus(email=email,description=description).save()
        messages.success(req,' Your Message Was Send Successfully')
        return redirect(contact_us)
    else:
        return render(req,'contactus.html')

def registration(req):
    if req.method == "POST":
        arf = Autocareform(req.POST)
        if arf.is_valid():
            arf.save()
    arf = Autocareform()  
    res= autocare.objects.all()  
     
    return render(req,'registration.html',{'form':arf,'data':res})       


def views(req):
    res=autocare.objects.all() #full data from autocare table
    return render(req,'view.html',{'data':res})     


def userhome(req):
    return render(req,'userhome.html')

def Repair(req):
    if req.method == 'POST':
        print(req.POST)
        car_name =req.POST['car_name']
        description = req.POST['description']
        email = req.POST['email']
        repair(car_name=car_name,description=description,email=email).save()
        messages.success(req,' Your Message Was Send Successfully')
        return redirect(Repair)
    else:
        return render(req,'repair.html')

def Booking(req,key):
    s=''
    if key>0:
        timeslots.objects.filter(id=key).update(status=True,email=req.session['email'])
        return HttpResponse("successful")
    if 'ok' in req.POST:
        dates =req.POST['dates']
        res = timeslots.objects.filter(date=dates,status=False)
        # for r in res:
        #     # s += "<a href = '{% url 'Booking' %d %}'>%s</a>&nbsp;"%(r.id,r.label)
        
        print(res)
        return render(req,'booking.html',{'data':res})

    else:
        return render(req,'booking.html')


def Spare(req):
    if req.method =="POST":
        sf = spareform(req.POST)
        if sf.is_valid():
            si = sf.cleaned_data['spare_id']
            spn = sf.cleaned_data['spare_name']
            spc = sf.cleaned_data['spare_price']
            spp = sf.cleaned_data['spare_photo']
            spare_bookings(spare_id=si,spare_name=spn,spare_price=spc,spare_photo=spp).save()
    res=spare_bookings.objects.all()
    return render(req,'spare.html',{"data":res})

def Delivery(req):
    res=car_delivery.objects.all() #full data from autocare table
    return render(req,'delivery.html',{'data':res})


def Order(req):
    return render(req,'order.html')

def Cars(req):
    if req.method =="POST":
        sf = carform(req.POST)
        if sf.is_valid():
            ci = sf.cleaned_data['c_id']
            cn = sf.cleaned_data['c_name']
            cp = sf.cleaned_data['c_photo']
            cd = sf.cleaned_data['c_description']
            car_sales(c_id=ci,c_name=cn,c_photo=cp,c_description=cd).save()
    res=car_sales.objects.all()
    return render(req,'cars.html',{"data":res})

def sbooking(req,key):
    if req.method=="POST":
        if req.POST.get("dateform"):
            date=req.POST['dates']
            print(date)
            bslots=slotbooked.objects.filter(date=date)
            aslot=Aviableslots.objects.all()
            aslots=set()
            for i in aslot:
                aslots.add(i)
                for j in bslots:
                        if j.slot == i.soltname:
                            aslots.remove(i)
                        
            return render(req,'booking.html',{'data':aslots,"date":date})
        elif req.POST.get('slotform'):
                print("datasave")
                id=key
                print(id)
                result=Aviableslots.objects.get(id=id)
                f=slotbooked(date=req.POST["date"],slot=result.soltname,bookeduser="nihal")
                f.save()
                return redirect('/Booking/0')
    email=req.session['email']
    print(email)
    res=Aviableslots.objects.all()
    # slots=slotbooked.objects.filter()
    # avl=Aviableslots.objects.get()
    # for d in slots:
    #     if avl.slotname in d.slot:
    return render(req,'booking.html',{'data':res})