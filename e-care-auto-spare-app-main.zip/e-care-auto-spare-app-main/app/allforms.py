
from django import forms
from .models import autocare,booking_wash,spare_bookings,car_sales

class Autocareform(forms.ModelForm):
    class Meta:
        model = autocare
        fields = '__all__'

class bookingform(forms.ModelForm):
    class Meta:
        model = booking_wash  
        fields = '__all__'      

class spareform(forms.ModelForm):
    class Meta:
        model = spare_bookings     
        fields = '__all__'

class carform(forms.ModelForm):
    class Meta:
        model = car_sales  
        fields = '__all__'     