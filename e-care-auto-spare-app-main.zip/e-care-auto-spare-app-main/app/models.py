
from operator import mod
from pyexpat import model
from statistics import mode
from tkinter import CASCADE
from django.db import models
from sqlalchemy import false

# Create your models here.
class autocare(models.Model):
    name = models.CharField(max_length=60)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=12)
    Address = models.TextField(max_length=100)
    dob = models.DateField()
    password = models.CharField(max_length=50)


class booking_wash(models.Model):
    bname = models.CharField(max_length=60)
    slot_time = models.DateTimeField()
    b_date = models.DateField()

class car_delivery(models.Model):
    available_on = models.DateField()
    invoice_no = models.IntegerField()
    status =models.CharField(max_length=15)     

class spare_bookings(models.Model):
    spare_id = models.IntegerField()
    spare_name = models.CharField(max_length=60)  
    spare_price = models.BigIntegerField()
    spare_photo = models.ImageField(upload_to='upload')  
      
    
class car_sales(models.Model):
    c_id = models.IntegerField()
    c_name = models.CharField(max_length=60)
    c_photo = models.ImageField(upload_to='upload')
    c_description = models.CharField(max_length=150)

class timeslots(models.Model):
    label = models.CharField(max_length=50)
    status = models.BooleanField(default=False)
    date = models.DateField(auto_now_add=True)
    email = models.EmailField(null=True,blank=True)
class Aviableslots(models.Model):
    soltname=models.CharField(max_length=15)
    time_slots=models.CharField(max_length=30)
    def __str__(self) -> str:
        return self.soltname
class slotbooked(models.Model):
    date=models.DateField()
    slot=models.CharField(max_length=25)
    bookeduser=models.CharField(max_length=10)

class repair(models.Model):
    car_name = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    email =models.EmailField()


class contactus(models.Model):
    email =models.EmailField()
    description = models.CharField(max_length=500)
    
