function myFunction() {
    alert("AVAILABLE FOR A TEST DRIVE");  
    
  }


function myFunction2() {
    alert("THE SPARE IS AVAILABLE AT SHOP");  
    
  }