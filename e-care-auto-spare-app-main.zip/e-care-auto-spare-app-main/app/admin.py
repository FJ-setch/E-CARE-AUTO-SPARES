from re import I
from django.contrib import admin
from .models import autocare,booking_wash, car_delivery, contactus, repair, slotbooked,spare_bookings,car_sales,timeslots,Aviableslots
from django import forms

# Register your models here.
@admin.register(autocare)
class adminbio(admin.ModelAdmin):
    list_display=[
        'name'
    ]
@admin.register(booking_wash)
class adminbooking(admin.ModelAdmin):
    list_display=[
        'bname','slot_time','b_date'
    ]
@admin.register(spare_bookings)
class adminspare(admin.ModelAdmin):
    list_display=[
        'spare_id','spare_name','spare_photo'
    ]
@admin.register(car_sales)
class admincar(admin.ModelAdmin):
    list_display=[
        'c_id','c_name','c_photo','c_description'
    ]
@admin.register(timeslots)
class admincar(admin.ModelAdmin):
    list_display=[
        'date','status'
    ]
    # def get_form(self):
    #     form=super().get_form()
    #     form.fields['email'].widget=forms.EmailInput(attrs={'hidden'})
    #     return form
admin.site.register(Aviableslots)
admin.site.register(slotbooked)
admin.site.register(repair)
admin.site.register(contactus)
admin.site.register(car_delivery)
