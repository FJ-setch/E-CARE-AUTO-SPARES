from xml.dom.minidom import Document
from django.urls import path
from .views import index,login,logout,registration,aboutus,contact_us,views,userhome,Profile
from .views import Repair,Booking,Spare,Delivery,Order,Cars,sbooking
from django.conf import settings
from django.conf.urls.static import static
urlpatterns=[
    path('',index,name="index"),
    # path('home/',fun1,name='home'),
    path('registration/',registration,name='registration'),
    path('view/',views,name='views'),
    path('login/',login,name='login'),
    path('aboutus/',aboutus,name='aboutus'),
    path('contactus/',contact_us,name='contactus'),
    path('userhome/',userhome,name='userhome'),
    path('Profile/',Profile,name='Profile'),
    # path('home/',home.as_view(),name='home'),
    path('logout/',logout,name='logout'),
    path('Repair/',Repair,name='Repair'),
    # path('Booking/<int:key>',Booking,name='Booking'),
    
    path('Booking/<int:key>',sbooking,name='Booking'),
    path('Spare/',Spare,name='Spare'),
    path('Delivery/',Delivery,name='Delivery'),
    # path('Payment/',Payment,name='Payment'),
    path('Order/',Order,name='Order'),
    path('Cars/',Cars,name='Cars'),

]
urlpatterns=urlpatterns+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)